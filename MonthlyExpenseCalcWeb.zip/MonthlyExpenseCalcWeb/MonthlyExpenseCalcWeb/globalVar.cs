﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonthlyExpenseCalcWeb
{
    public class globalVar
    {
        private static string usernam = "";

        public static string Username
        {
            get { return usernam;  }
            set { usernam = value; }
        }

        public string user { get; set; }
    }
}