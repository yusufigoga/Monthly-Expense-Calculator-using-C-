﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonthlyExpenseCalcWeb
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //threading method
        public void threading()
        {
            Thread.Sleep(1000);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtUsername.Text))
            {
                Response.Write("Please enter Username!");
            }
            else if (String.IsNullOrEmpty(txtPassword.Text))
            {
                Response.Write("Please enter Password!");
            }
            else
            {
                //giving the nextboxes a varibale for easier use
                string username = txtUsername.Text;
                string password = txtPassword.Text;

                //Create the salt value with a cryptographic PRNG
                byte[] cord;
                new RNGCryptoServiceProvider().GetBytes(cord = new byte[16]);

                //Create the Rfc2898DeriveBytes and get the hash value
                var temp = new Rfc2898DeriveBytes(password, cord, 100000);
                byte[] hash = temp.GetBytes(20);

                //Combine the salt and password bytes for later use
                byte[] hashBytes = new byte[36];
                Array.Copy(cord, 0, hashBytes, 0, 16);
                Array.Copy(hash, 0, hashBytes, 16, 20);

                //Turn the combined salt+hash into a string for storage
                string savedPassword = Convert.ToBase64String(hashBytes);


                try
                {
                    //connecting to database
                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
                    //opening connection
                    con.Open();
                    //creating a query for easier use
                    string query = "INSERT INTO login (Username, Password)  VALUES ('" + username + "', '" + savedPassword + "')";

                    //reading the data
                    SqlDataReader sdr = new SqlCommand(query, con).ExecuteReader();
                    threading();
                    //closing connection
                    con.Close();

                    //opening connection
                    con.Open();
                    //creating a query for easier use
                    string query2 = "INSERT INTO Expenses (Username) VALUES ('" + username + "')";
                    //reading the data
                    SqlDataReader Sdp = new SqlCommand(query2, con).ExecuteReader();
                    threading();
                    //closing connection
                    con.Close();
                    //going to login page if registration is successful
                    Response.Redirect("Login.aspx");

                }
                //Exception handling
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }
    }
 }
