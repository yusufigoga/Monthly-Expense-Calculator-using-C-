﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonthlyExpenseCalcWeb
{
    public class Expenses
    {

        public int income { get; set; }
        public int tax { get; set; }
        public int groceries { get; set; }
        public int waterLights { get; set; }
        public int travel { get; set; }
        public int phone { get; set; }
        public int other { get; set; }
        public int rent { get; set; }
    }
}