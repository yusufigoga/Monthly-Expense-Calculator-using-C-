﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonthlyExpenseCalcWeb
{
    public class Saving
    {
        public string reason { get; set; }
        public int price { get; set; }
        public int intrest { get; set; }
        public int time { get; set; }
    }
}