﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonthlyExpenseCalcWeb
{
    public class Property
    {
        public int price { get; set; }
        public int deposit { get; set; }
        public int intrest { get; set; }
        public int time { get; set; }
    }
}