﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonthlyExpenseCalcWeb
{
    public partial class Login : System.Web.UI.Page
    {
        
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //threading method
        public void threading()
        {
            Thread.Sleep(1000);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            //saving values from textbox into a vrable for easy use 
             string username = txtUsername.Text;
            string password = txtPassword.Text;

            try
            {
                //connecting to the database
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
                //opening the connection
                con.Open();

                {
                    string hashQuery = "SELECT Password, Username from Login WHERE Username = '" + username + "'";
                    //reading the query from the database
                    SqlDataReader sdf = new SqlCommand(hashQuery, con).ExecuteReader();
                    //this we calling the thread
                    threading();
                    //checking to see if username if correct
                    if (sdf.Read())
                    {
                        //Fetch the stored value
                        string savedPasswordHash = sdf[0].ToString();
                        //Extract the bytes
                        byte[] hashBytes = Convert.FromBase64String(savedPasswordHash);
                        //Get the salt
                        byte[] salt = new byte[16];
                        Array.Copy(hashBytes, 0, salt, 0, 16);
                        // Compute the hash on the password the user entered
                        var pbkdf2 = new Rfc2898DeriveBytes(password, salt, 100000);
                        byte[] hash = pbkdf2.GetBytes(20);

                        //Compare the results
                        for (int i = 0; i < 20; i++)
                            if (hashBytes[i + 16] != hash[i])
                                throw new UnauthorizedAccessException();

                        //closing the connection
                        con.Close();

                        //opening the connection
                        con.Open();

                        //query to check is user and password is correct
                        string query = "SELECT * FROM login WHERE Username= '" + username + "' AND Password= '" + savedPasswordHash + "'";
                        //reading the query
                        SqlDataReader sdr = new SqlCommand(query, con).ExecuteReader();
                        threading();
                        //if user name and password are correct then go to the next form 
                        if (sdr.Read())
                        {
                            //going to the next form and passing the username to the next table
                            globalVar.Username = username;
                            Session["username"] = username;
                            Response.Redirect("MonthlyExpenseCalculator.aspx?username" +username);

                        }


                        //if password is incorrect show error
                        else
                        {
                            Response.Write("Invalid login.... try again");
                        }
                        con.Close();




                    }
                    //if username is incorrect show error
                    else
                    {
                        Response.Write("Invalid login.... try again");
                    }

                }
            }

            //exception handling
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}