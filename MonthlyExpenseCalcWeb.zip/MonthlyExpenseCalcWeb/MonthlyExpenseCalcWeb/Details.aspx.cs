﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonthlyExpenseCalcWeb
{
    public partial class Details : System.Web.UI.Page
    {
        //creating a temp variable for the username 
        public string currD;

        protected void Page_Load(object sender, EventArgs e)
        {
            //calling username from the login page
            currD = (string)(Session["username"]);

            //connecting to the database
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
            //opening the connection
            con.Open();

            //updating the expenses table
            string query = "SELECT Income, Tax, General, Rent, Property, Car, Total, Savings from Expenses WHERE Username = '" + currD + "'";
            //reading the query from the database
            SqlDataReader sdf = new SqlCommand(query, con).ExecuteReader();

            if (sdf.Read())
            {
                //calling information from database into the textboxes
                txtIncome.Text = (sdf["Income"].ToString());
                txtTax.Text = (sdf["Tax"].ToString());
                txtGeneral.Text = (sdf["General"].ToString());
                txtRent.Text = (sdf["Rent"].ToString());
                txtProperty.Text = (sdf["Property"].ToString());
                txtCar.Text = (sdf["Car"].ToString());
                txtSave.Text = (sdf["Savings"].ToString());
                txtTotal.Text = (sdf["Total"].ToString());
            }
            //closing the connection
            con.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("MonthlyExpenseCalculator.aspx");
        }
    }
}