﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonthlyExpenseCalcWeb
{
    public class Car
    {
        public string make { get; set; }
        public int price { get; set; }
        public int deposit { get; set; }
        public int intrest { get; set; }
        public int insurnace { get; set; }
    }
}