﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonthlyExpenseCalcWeb
{
   
    
    public partial class MonthlyExpenseCalculator : System.Web.UI.Page
    {
        // using the generic classes to store the information 
        List<Expenses> ExpensesList = new List<Expenses>();
        List<Property> PropExpenses = new List<Property>();
        List<Car> CarExpenses = new List<Car>();

        //creating a temp variable for the username 
        public string curr;

       
        

        //creating a varibale for the totals
        double total;
        double expense;
        double totalProp;
        double totalCar;
        double totalSave;



        protected void Page_Load(object sender, EventArgs e)
        {
            //calling username from the login page
            globalVar gv = new globalVar();
           
        }
        public void threading()
        {
            Thread.Sleep(1000);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //calling username from the login page
            curr = (string)(Session["username"]);

            //calling the class
            Expenses expensesObj = new Expenses();

            //read expenses into object properties
            expensesObj.income = int.Parse(textBoxMonthlyIncome.Text);
            expensesObj.tax = int.Parse(textBoxTax.Text);
            expensesObj.groceries = int.Parse(textBoxGroceries.Text);
            expensesObj.waterLights = int.Parse(textBoxWaterAndLights.Text);
            expensesObj.travel = int.Parse(textBoxTravel.Text);
            expensesObj.phone = int.Parse(textBoxPhone.Text);
            expensesObj.other = int.Parse(textBoxOther.Text);

            //total of the general expenses
            expense = (expensesObj.tax + expensesObj.groceries + expensesObj.waterLights + expensesObj.travel + expensesObj.phone + expensesObj.other);
            //calculating total after basic expenses
            total = expensesObj.income - expense;

            threading();

            //checking if radio button is clicked 
            if (RadioButton1.Checked == true)
            {
                //calculating the total amount of money after rent has been entered
                expensesObj.rent = int.Parse(textBoxRent.Text);
                total = total - expensesObj.rent;
            }

            else if (RadioButton2.Checked == true)
            {
                //temporary place holder
                double temp;
                //calling the class
                Property prop = new Property();
                //read property purhcase expense inhto object properties
                prop.price = int.Parse(textBoxPriceProperty.Text);
                prop.deposit = int.Parse(textBoxDeposit.Text);
                prop.intrest = int.Parse(textBoxIntrest.Text);
                prop.time = int.Parse(textBoxRepay.Text);

                //P = temp R = prop.intretest  T = 20 or 25 or 30
                //I = P*R*T
                temp = prop.price - prop.deposit;
                double temp2 = temp * (prop.intrest * 0.01) * (prop.time / 12);

                // temp * (7 * 0.01) * (prop.time / 12)

                // A=temp3 P=temp I= temp2
                //A = P+I
                double temp3 = temp + temp2;

                //A = temp3 Months = prop.time
                //A/Months = Monthly repayment
                totalProp = temp3 / prop.time;

               

                //Error message that will show if the monthly price for property is >1/3 of Income
                if (totalProp > (expensesObj.income * 0.3333))
                {
                    total = total - totalProp;

                }
                // if everything is in order it will deduct the monthly property price from total Earnings
                else
                {
                    total = total - totalProp;
                }

            }
            threading();

            if(CheckBox1.Checked == true)
            {
                //calling the class
                Car car = new Car();
                //read car purhcase expense inhto object properties
                car.make = textBoxModel.Text;
                car.price = int.Parse(textBoxCarPrice.Text);
                car.deposit = int.Parse(textBoxCarDdeposit.Text);
                car.intrest = int.Parse(textBoxIntrestRate.Text);
                car.insurnace = int.Parse(textBoxInsurnace.Text);

                //creating a varibale for the total monthly due at end
                double temp;

                //P = temp R = prop.intretest  T = 20 or 25 or 30
                //I = P*R*T
                temp = car.price - car.deposit;
                double temp2 = temp * (car.intrest * 0.01) * 5;

                // A=temp3 P=temp I= temp2
                //A = P+I
                double temp3 = temp + temp2;

                //A = temp3 Months = prop.time
                //A/Months = Monthly repayment
                totalCar = temp3 / 60;
                totalCar = totalCar - car.insurnace;


                //total after car deductions
                total = total - totalCar;

                threading();
            }

            if(Savings.Checked == true)
            {
                //read savings purhcase expense inhto object properties
                Saving sav = new Saving();
                sav.reason = txtReason.Text;
                sav.price = int.Parse(txtAmount.Text);
                sav.intrest = int.Parse(txtInt.Text);
                sav.time = int.Parse(txtMonths.Text);

                //going the caculation for intrest
                double temp = sav.price * (sav.intrest * 0.01) * (sav.time / 12);
                double temp2 = sav.price + temp;
                totalSave = temp2 / sav.time;

                total = total - totalSave;
            }

            //connecting to the database
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
            //opening the connection
            con.Open();

            //updating the expenses table
            string query = "UPDATE Expenses SET Income =  '" + expensesObj.income + "', Tax= '" + expensesObj.tax + "',General= '" + expense + "', Rent= '" + expensesObj.rent + "', Property= '" + totalProp + "', Car= '" + totalCar + "', Total= '" + total + "', Savings= '" + totalSave + "' WHERE Username = '" + curr + "'";
            //reading the query from the database
            SqlDataReader sdf = new SqlCommand(query, con).ExecuteReader();
            threading();
            //this we calling the thread
            threading();

            Response.Redirect("Details.aspx");

            

        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Response.Redirect("Details.aspx");
        }

       
    }
}